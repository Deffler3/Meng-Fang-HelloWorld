﻿namespace HelloWorldAPI
{
    public interface IMessage
    {
          string WriteMessage();
    }

    public abstract class AbstractMessage :IMessage
    {
        public string MessageValue;
        public string WriteType;
        public string WriteMessage()
        {
            switch (WriteType)
            {
                case "database":
                    // write to database;
                    break;
                case "file":
                    // write to file;
                    break;
                default:
                    // default write;
                    break;
            }
            return MessageValue + WriteType;
        }

    }

    public class Message : AbstractMessage
    {
        
        public  Message(string messageValue, string writeType) {
            MessageValue = messageValue;
            WriteType = writeType;
        }

    }
}
