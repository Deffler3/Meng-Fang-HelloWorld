﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using HelloWorldAPI;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Start Write:  ");
            string currentApplication = ConfigurationSettings.AppSettings["CurrentApplication"];
            string writeType = ConfigurationSettings.AppSettings["WriteType"];
            AbstractMessage message = new Message(currentApplication, writeType);
            message.WriteMessage();
        }
    }
}
