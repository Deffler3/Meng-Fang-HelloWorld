﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HelloWorldAPI;

namespace APITest
{
    [TestClass]
    public class MessageTest

    {
        [TestMethod]
        public void TestMessageWriteCorrectMessageandType()
        {
            Message testMessage = new Message("test application"," test write type");
            Assert.AreEqual("test application test write type", testMessage.WriteMessage());
        }
    }
}
